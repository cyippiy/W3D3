# == Schema Information
#
# Table name: shortened_urls
#
#  id         :bigint(8)        not null, primary key
#  long_url   :string
#  false      :integer
#  short_url  :string
#  user_id    :integer
#  created_at :datetime         not null
#  updated_at :datetime         not null
#

class ShortenedUrl < ApplicationRecord
  validates :long_url, :short_url, presence: true, uniqueness: true

  def self.random_code
    short_num = SecureRandom.urlsafe_base64(12)
    until !(self.exists?(short_num))
      short_num = SecureRandom.urlsafe_base64(12)
    end
    "www.shawwttaaaayyyy.com/#{short_num}"
  end

  def self.create!(user,long_url)
    ShortenedUrl.create(long_url: long_url,short_url: ShortenedUrl.random_code,user_id: user.id)
  end

  belongs_to :submitter,
  primary_key: :id,
  foreign_key: :user_id,
  class_name: :User

  has_many :visits,
  primary_key: :id,
  foreign_key: :short_id,
  class_name: :Visit
end
